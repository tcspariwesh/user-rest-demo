package com.example.rest.service;

import com.example.rest.entity.User;

public interface IUserService {

	void createUser(User user);
	
}
